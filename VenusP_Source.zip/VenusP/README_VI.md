# VenusP — Android music player (Rust core)

VenusP là bản MVP Android với giao diện tối kiểu glassmorphism, trình phát Media3 và một lõi Rust kiểm tra liên kết âm thanh.

## Tính năng có trong bản này

- Chọn và phát tệp âm thanh từ điện thoại qua Android System Document Picker.
- Dán URL HTTPS trực tiếp cho MP3, M4A, AAC, OGG/OGA, OPUS, FLAC, WAV hoặc luồng HLS M3U8.
- Play/Pause, tua bài, bài trước/bài tiếp, hàng đợi, shuffle, repeat.
- Đánh dấu yêu thích và lưu cục bộ trên thiết bị.
- MediaSessionService để hỗ trợ phát nền và điều khiển từ thông báo/màn hình khóa của Android.
- Phần kiểm tra URL được viết bằng Rust qua JNI.

## Giới hạn có chủ đích

VenusP không mở khóa Spotify Premium, không tải/rip nhạc từ trang Spotify/YouTube, không vượt paywall, không gỡ quảng cáo của dịch vụ khác và không giải mã nội dung bị bảo vệ. Liên kết trang nghe nhạc không phải URL âm thanh trực tiếp nên sẽ bị từ chối. Chỉ dùng tệp/luồng mà bạn sở hữu hoặc được phép truy cập.

Đây là MVP độc lập, chưa phải bản thay thế toàn bộ Spotify: chưa có catalog nhạc thương mại, tài khoản/cloud sync, gợi ý cá nhân, lyrics, social, podcast, equalizer nâng cao hay tìm kiếm toàn internet.

## Cấu trúc

- `app/`: Android UI Kotlin + Media3 playback/session.
- `rust-core/`: thư viện Rust `cdylib`, được gọi từ Kotlin qua JNI.

## Phiên bản công cụ được cấu hình

- Rust stable: 1.99.1 (cập nhật stable sau này được, nhưng hãy build/test lại).
- Android Gradle Plugin: 8.13.2.
- Gradle: 8.13.
- Kotlin Gradle Plugin: 2.4.21.
- Android compile/target SDK: 36.
- AndroidX Media3: 1.11.1.
- Java: 17 trở lên (JDK 21 cũng phù hợp với cấu hình này).

## Cách build APK trên máy tính

Cần Android Studio, Android SDK Platform 36, Android NDK side-by-side, JDK 17+ và kết nối mạng lần đầu để Gradle tải dependencies.

1. Cài Rust stable và các target Android:

   ```bash
   rustup toolchain install 1.99.1
   rustup default 1.99.1
   rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
   cargo install cargo-ndk
   ```

2. Trong Android Studio, mở thư mục `VenusP/` và cài Android SDK Platform 36 cùng Android NDK trong SDK Manager.
3. Đặt `ANDROID_HOME` trỏ tới thư mục Android SDK. Nếu cargo-ndk chưa tự tìm được NDK, đặt thêm `ANDROID_NDK_HOME` trỏ tới thư mục NDK đã cài.
4. Chạy build bằng Android Studio: **Build → Build Bundle(s) / APK(s) → Build APK(s)**, hoặc từ terminal tại thư mục dự án:

   ```bash
   gradle :app:assembleDebug
   ```

5. APK debug sau khi build nằm tại:

   ```text
   app/build/outputs/apk/debug/app-debug.apk
   ```

Khi build lần đầu, Gradle sẽ chạy task `buildRust` để sinh thư viện native cho các ABI `arm64-v8a`, `armeabi-v7a` và `x86_64`, sau đó đóng gói vào APK.

## Cài trên điện thoại

Chép `app-debug.apk` sang Android và mở để cài. Android có thể yêu cầu bạn cho phép cài ứng dụng từ nguồn bạn đang dùng; đây là bước bảo vệ của hệ điều hành và không thể tự bỏ qua. Để hiện điều khiển nhạc/notification đầy đủ trên Android mới, hãy cho phép thông báo khi hệ điều hành hỏi.

## Kiểm tra Rust

Từ thư mục dự án:

```bash
cd rust-core
cargo test
```

## Lưu ý phát triển

Bản mã nguồn này được tạo trong môi trường không có Rust, Gradle hoặc Android SDK và không có kết nối tải dependencies, nên APK chưa được biên dịch/chạy thử tại đây. Hãy build bằng Android Studio theo các bước trên trước khi cài lên thiết bị thật.

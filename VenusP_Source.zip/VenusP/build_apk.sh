#!/usr/bin/env bash
set -euo pipefail

if ! command -v cargo >/dev/null 2>&1; then
  echo "Rust/Cargo chưa được cài." >&2
  exit 1
fi
if ! command -v cargo-ndk >/dev/null 2>&1 && ! cargo ndk --version >/dev/null 2>&1; then
  echo "Thiếu cargo-ndk. Cài bằng: cargo install cargo-ndk" >&2
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Thiếu Gradle. Hãy mở dự án bằng Android Studio hoặc cài Gradle 8.13." >&2
  exit 1
fi

gradle :app:assembleDebug
printf '\nAPK: app/build/outputs/apk/debug/app-debug.apk\n'

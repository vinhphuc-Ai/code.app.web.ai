package com.venusp.player

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.Executor
import kotlin.math.max

private data class QueueEntry(val item: MediaItem, val title: String)

class MainActivity : Activity() {
    private val purple = Color.rgb(196, 181, 253)
    private val white = Color.WHITE
    private val muted = Color.rgb(184, 188, 211)
    private val handler = Handler(Looper.getMainLooper())
    private val pendingItems = mutableListOf<MediaItem>()
    private val localQueue = mutableListOf<QueueEntry>()
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var draggingSeekBar = false

    private lateinit var urlInput: EditText
    private lateinit var statusText: TextView
    private lateinit var titleText: TextView
    private lateinit var subtitleText: TextView
    private lateinit var playButton: TextView
    private lateinit var favoriteButton: TextView
    private lateinit var shuffleButton: TextView
    private lateinit var repeatButton: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var timeText: TextView
    private lateinit var queueList: LinearLayout

    private val progressTicker = object : Runnable {
        override fun run() {
            updatePlaybackUi()
            handler.postDelayed(this, 500)
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            updatePlaybackUi()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17, 19, 38)
        window.navigationBarColor = Color.rgb(17, 19, 38)
        window.decorView.systemUiVisibility = 0
        buildInterface()
    }

    override fun onStart() {
        super.onStart()
        connectPlaybackController()
        handler.post(progressTicker)
    }

    override fun onStop() {
        handler.removeCallbacks(progressTicker)
        controller?.removeListener(playerListener)
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onStop()
    }

    private fun connectPlaybackController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        controllerFuture = future
        future.addListener({
            runOnUiThread {
                try {
                    val connected = future.get()
                    controller = connected
                    connected.addListener(playerListener)
                    if (pendingItems.isNotEmpty()) {
                        connected.setMediaItems(pendingItems.toList())
                        pendingItems.clear()
                        connected.prepare()
                        connected.play()
                    }
                    updatePlaybackUi()
                } catch (_: Exception) {
                    showStatus("Không kết nối được trình phát. Hãy thử mở lại VenusP.")
                }
            }
        }, Executor { command -> command.run() })
    }

    private fun buildInterface() {
        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(16, 18, 39), Color.rgb(37, 32, 73), Color.rgb(18, 27, 51))
            )
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(18), dp(18), dp(18), dp(26))
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = text("VenusP", 23f, white, true)
        brand.letterSpacing = 0.02f
        brandRow.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        brandRow.addView(text("MUSIC PLAYER", 10f, muted, true))
        content.addView(brandRow)

        val heading = text("Âm nhạc\ncủa bạn.", 32f, white, true).apply {
            setLineSpacing(dp(1).toFloat(), 1.0f)
        }
        val headingParams = lp(-1, -2).apply { topMargin = dp(22); bottomMargin = dp(18) }
        content.addView(heading, headingParams)

        val linkCard = glassCard()
        content.addView(linkCard, lp(-1, -2).apply { bottomMargin = dp(14) })
        linkCard.addView(text("PHÁT TỪ LIÊN KẾT", 11f, purple, true))
        linkCard.addView(text("Dán URL âm thanh trực tiếp mà bạn có quyền nghe.", 13f, muted, false), lp(-1, -2).apply { topMargin = dp(6) })
        urlInput = EditText(this).apply {
            hint = "https://example.com/song.mp3"
            setHintTextColor(Color.rgb(137, 143, 169))
            setTextColor(white)
            textSize = 14f
            singleLine = true
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(Color.argb(34, 255, 255, 255), 15f, Color.argb(55, 255, 255, 255))
        }
        linkCard.addView(urlInput, lp(-1, dp(50)).apply { topMargin = dp(14) })
        val playLink = actionButton("Phát liên kết", true)
        linkCard.addView(playLink, lp(-1, dp(48)).apply { topMargin = dp(11) })
        playLink.setOnClickListener { playPastedLink() }

        val fileButton = actionButton("＋  Chọn nhạc trong điện thoại", false)
        linkCard.addView(fileButton, lp(-1, dp(46)).apply { topMargin = dp(9) })
        fileButton.setOnClickListener { openAudioPicker() }

        statusText = text("Sẵn sàng phát nhạc", 12f, muted, false)
        content.addView(statusText, lp(-1, -2).apply { topMargin = dp(5); bottomMargin = dp(14) })

        val playerCard = glassCard()
        content.addView(playerCard, lp(-1, -2).apply { bottomMargin = dp(14) })
        val art = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(111, 91, 190), Color.rgb(50, 75, 126), Color.rgb(30, 39, 72))
            ).apply { cornerRadius = dp(23).toFloat() }
        }
        val artGlyph = text("♫", 70f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        art.addView(artGlyph, FrameLayout.LayoutParams(-1, -1))
        playerCard.addView(art, lp(-1, dp(190)))

        titleText = text("Chưa phát nhạc", 20f, white, true)
        playerCard.addView(titleText, lp(-1, -2).apply { topMargin = dp(18) })
        subtitleText = text("Thêm một bài hát để bắt đầu", 13f, muted, false)
        playerCard.addView(subtitleText, lp(-1, -2).apply { topMargin = dp(5) })

        seekBar = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(white)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(80, 255, 255, 255))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) = Unit
                override fun onStartTrackingTouch(bar: SeekBar?) { draggingSeekBar = true }
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    val p = controller ?: return
                    val duration = p.duration
                    if (duration > 0 && bar != null) {
                        p.seekTo((duration * bar.progress / 1000).coerceIn(0L, duration))
                    }
                    draggingSeekBar = false
                }
            })
        }
        playerCard.addView(seekBar, lp(-1, dp(34)).apply { topMargin = dp(14) })
        timeText = text("0:00                                      0:00", 11f, muted, false)
        playerCard.addView(timeText, lp(-1, -2))

        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
        }
        val previous = controlButton("|‹", 22f)
        playButton = controlButton("▶", 25f, true)
        val next = controlButton("›|", 22f)
        controls.addView(previous, lp(dp(58), dp(54)))
        controls.addView(playButton, lp(dp(76), dp(64)).apply { leftMargin = dp(12); rightMargin = dp(12) })
        controls.addView(next, lp(dp(58), dp(54)))
        playerCard.addView(controls, lp(-1, dp(72)).apply { topMargin = dp(10) })
        previous.setOnClickListener {
            controller?.let { p -> if (p.hasPreviousMediaItem()) p.seekToPreviousMediaItem() else p.seekTo(0) }
        }
        next.setOnClickListener {
            controller?.let { p -> if (p.hasNextMediaItem()) p.seekToNextMediaItem() else p.seekTo(0) }
        }
        playButton.setOnClickListener {
            controller?.let { p -> if (p.isPlaying) p.pause() else p.play() }
        }

        val options = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        shuffleButton = smallPill("Trộn: Tắt")
        repeatButton = smallPill("Lặp: Tắt")
        favoriteButton = smallPill("♡ Yêu thích")
        options.addView(shuffleButton, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(5) })
        options.addView(repeatButton, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5); rightMargin = dp(5) })
        options.addView(favoriteButton, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(5) })
        playerCard.addView(options, lp(-1, dp(44)).apply { topMargin = dp(8) })
        shuffleButton.setOnClickListener {
            controller?.let { p -> p.shuffleModeEnabled = !p.shuffleModeEnabled; updatePlaybackUi() }
        }
        repeatButton.setOnClickListener {
            controller?.let { p ->
                p.repeatMode = when (p.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
                updatePlaybackUi()
            }
        }
        favoriteButton.setOnClickListener { toggleFavorite() }

        val queueCard = glassCard()
        content.addView(queueCard, lp(-1, -2).apply { bottomMargin = dp(12) })
        val queueHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        queueHeader.addView(text("Hàng đợi phát", 17f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        queueHeader.addView(text("ON DEVICE", 10f, purple, true))
        queueCard.addView(queueHeader, lp(-1, -2))
        queueList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        queueCard.addView(queueList, lp(-1, -2).apply { topMargin = dp(12) })
        renderQueue()

        val footer = text("VenusP chỉ phát tệp của bạn và URL âm thanh trực tiếp được phép truy cập. Không mở khóa dịch vụ trả phí hoặc gỡ quảng cáo.", 11f, muted, false).apply {
            gravity = Gravity.CENTER
            setLineSpacing(dp(3).toFloat(), 1.0f)
        }
        content.addView(footer, lp(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(12) })
    }

    private fun playPastedLink() {
        val url = urlInput.text?.toString()?.trim().orEmpty()
        val validation = try {
            RustCore().validateAudioUrl(url)
        } catch (_: UnsatisfiedLinkError) {
            "Thiếu thư viện Rust. Cần build ứng dụng bằng Android NDK trước."
        } catch (_: Exception) {
            "Không thể kiểm tra liên kết này."
        }

        if (validation != "OK") {
            showStatus(validation)
            return
        }
        val name = url.substringBefore('?').substringAfterLast('/').ifBlank { "Bài hát từ liên kết" }
        addTrack(Uri.parse(url), name)
        urlInput.setText("")
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(urlInput.windowToken, 0)
        showStatus("Đã thêm vào hàng đợi")
    }

    private fun openAudioPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, REQUEST_AUDIO)
        } catch (_: Exception) {
            showStatus("Thiết bị không mở được trình chọn tệp.")
        }
    }

    @Deprecated("Uses the system document picker for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_AUDIO || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val readFlag = data.flags and Intent.FLAG_GRANT_READ_URI_PERMISSION
            if (readFlag != 0) contentResolver.takePersistableUriPermission(uri, readFlag)
        } catch (_: Exception) {
            // Some document providers grant a temporary read permission only.
        }
        val title = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')
            ?.ifBlank { "Nhạc trong điện thoại" } ?: "Nhạc trong điện thoại"
        addTrack(uri, title)
        showStatus("Đã thêm tệp âm thanh")
    }

    private fun addTrack(uri: Uri, title: String) {
        val metadata = MediaMetadata.Builder().setTitle(title).setArtist("VenusP").build()
        val item = MediaItem.Builder().setUri(uri).setMediaMetadata(metadata).build()
        localQueue.add(QueueEntry(item, title))
        renderQueue()

        val p = controller
        if (p == null) {
            pendingItems.add(item)
            showStatus("Đã xếp bài. Đang kết nối trình phát…")
            return
        }
        val index = p.mediaItemCount
        p.addMediaItem(item)
        if (index == 0) p.prepare()
        p.seekTo(index, 0L)
        p.play()
    }

    private fun renderQueue() {
        if (!::queueList.isInitialized) return
        queueList.removeAllViews()
        if (localQueue.isEmpty()) {
            queueList.addView(text("Chưa có bài hát nào. Hãy chọn tệp hoặc dán URL trực tiếp.", 12f, muted, false))
            return
        }
        localQueue.takeLast(12).forEachIndexed { index, entry ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(9), dp(4), dp(9))
            }
            val number = text("${max(1, localQueue.size - minOf(12, localQueue.size) + index + 1)}", 12f, purple, true)
            row.addView(number, lp(dp(30), -2))
            row.addView(text(entry.title, 13f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text("♫", 17f, muted, false))
            row.setOnClickListener {
                val p = controller
                val selectedIndex = localQueue.indexOf(entry)
                if (p != null && selectedIndex >= 0) {
                    // The queue view tracks items added during this app session.
                    p.seekTo(selectedIndex, 0L)
                    p.play()
                }
            }
            queueList.addView(row)
            if (index < minOf(12, localQueue.size) - 1) {
                val divider = View(this).apply { setBackgroundColor(Color.argb(28, 255, 255, 255)) }
                queueList.addView(divider, lp(-1, dp(1)))
            }
        }
    }

    private fun toggleFavorite() {
        val currentUri = controller?.currentMediaItem?.localConfiguration?.uri?.toString()
        if (currentUri.isNullOrBlank()) {
            showStatus("Hãy phát một bài hát trước.")
            return
        }
        val prefs = getSharedPreferences("venusp_library", MODE_PRIVATE)
        val favorites = prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
        val added = if (favorites.contains(currentUri)) {
            favorites.remove(currentUri)
            false
        } else {
            favorites.add(currentUri)
            true
        }
        prefs.edit().putStringSet("favorites", favorites).apply()
        favoriteButton.text = if (added) "♥ Đã thích" else "♡ Yêu thích"
        showStatus(if (added) "Đã lưu vào yêu thích" else "Đã bỏ khỏi yêu thích")
    }

    private fun updatePlaybackUi() {
        val p = controller
        val item = p?.currentMediaItem
        titleText.text = item?.mediaMetadata?.title?.toString() ?: "Chưa phát nhạc"
        subtitleText.text = item?.mediaMetadata?.artist?.toString() ?: "Thêm một bài hát để bắt đầu"
        playButton.text = if (p?.isPlaying == true) "Ⅱ" else "▶"
        shuffleButton.text = if (p?.shuffleModeEnabled == true) "Trộn: Bật" else "Trộn: Tắt"
        repeatButton.text = when (p?.repeatMode) {
            Player.REPEAT_MODE_ALL -> "Lặp: Tất cả"
            Player.REPEAT_MODE_ONE -> "Lặp: Một bài"
            else -> "Lặp: Tắt"
        }

        val currentUri = item?.localConfiguration?.uri?.toString()
        val favorites = getSharedPreferences("venusp_library", MODE_PRIVATE)
            .getStringSet("favorites", emptySet()) ?: emptySet()
        favoriteButton.text = if (currentUri != null && favorites.contains(currentUri)) "♥ Đã thích" else "♡ Yêu thích"

        val duration = p?.duration?.takeIf { it > 0 } ?: 0L
        val position = p?.currentPosition?.coerceAtLeast(0L) ?: 0L
        if (!draggingSeekBar) {
            seekBar.progress = if (duration > 0) ((position * 1000L) / duration).toInt().coerceIn(0, 1000) else 0
        }
        val left = formatTime(position)
        val right = if (duration > 0) formatTime(duration) else "0:00"
        timeText.text = "$left                                      $right"
    }

    private fun formatTime(milliseconds: Long): String {
        val total = milliseconds / 1000
        return String.format("%d:%02d", total / 60, total % 60)
    }

    private fun showStatus(message: String) {
        statusText.text = message
    }

    private fun glassCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(17), dp(17), dp(17))
        background = rounded(Color.argb(38, 255, 255, 255), 25f, Color.argb(58, 255, 255, 255))
    }

    private fun rounded(color: Int, radius: Float, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius.toInt()).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.NORMAL) else Typeface.create("sans-serif", Typeface.NORMAL)
        includeFontPadding = true
    }

    private fun actionButton(value: String, primary: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = 14f
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(if (primary) Color.rgb(27, 25, 49) else white)
        background = if (primary) {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFFD8CCFF.toInt(), 0xFFB8C7FF.toInt())).apply { cornerRadius = dp(16).toFloat() }
        } else {
            rounded(Color.argb(30, 255, 255, 255), 16f, Color.argb(56, 255, 255, 255))
        }
    }

    private fun controlButton(value: String, size: Float, primary: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(if (primary) Color.rgb(27, 25, 49) else white)
        background = rounded(
            if (primary) 0xFFD8CCFF.toInt() else Color.argb(35, 255, 255, 255),
            21f,
            Color.argb(65, 255, 255, 255)
        )
    }

    private fun smallPill(value: String): TextView = TextView(this).apply {
        text = value
        textSize = 10.5f
        gravity = Gravity.CENTER
        maxLines = 1
        setTextColor(white)
        background = rounded(Color.argb(32, 255, 255, 255), 14f, Color.argb(46, 255, 255, 255))
    }

    private fun lp(width: Int, height: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(width, height)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQUEST_AUDIO = 1402
    }
}

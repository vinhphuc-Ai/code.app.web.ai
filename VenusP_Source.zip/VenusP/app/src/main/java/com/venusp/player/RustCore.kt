package com.venusp.player

/** Thin JNI bridge: URL validation is implemented in Rust. */
class RustCore {
    companion object {
        init {
            System.loadLibrary("venus_core")
        }
    }

    external fun validateAudioUrl(url: String): String
}

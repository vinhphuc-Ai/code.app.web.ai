plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.venusp.player"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.venusp.player"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-session:1.11.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.11.1")
}

// Build the Rust validation library for Android before packaging the APK.
// Prerequisites: rustup targets + cargo-ndk + Android NDK.
val buildRust by tasks.registering(Exec::class) {
    workingDir(rootProject.file("rust-core"))
    commandLine(
        "cargo", "ndk",
        "-t", "arm64-v8a",
        "-t", "armeabi-v7a",
        "-t", "x86_64",
        "-o", project.file("src/main/jniLibs").absolutePath,
        "build", "--release"
    )
}

tasks.named("preBuild").configure {
    dependsOn(buildRust)
}

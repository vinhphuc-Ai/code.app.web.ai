use jni::objects::{JObject, JString};
use jni::sys::jstring;
use jni::JNIEnv;
use url::Url;

const ALLOWED_EXTENSIONS: &[&str] = &[
    "mp3", "m4a", "aac", "ogg", "oga", "opus", "flac", "wav", "m3u8",
];

/// Validates a direct audio URL. VenusP deliberately does not extract audio
/// from Spotify/YouTube pages or bypass subscriptions, ads, or access controls.
pub fn validate_audio_url(input: &str) -> Result<(), &'static str> {
    let trimmed = input.trim();
    if trimmed.is_empty() {
        return Err("Vui lòng dán liên kết trước.");
    }

    let parsed = Url::parse(trimmed).map_err(|_| "Liên kết không hợp lệ.")?;
    if parsed.scheme() != "https" {
        return Err("Chỉ hỗ trợ liên kết HTTPS an toàn.");
    }

    let host = parsed.host_str().unwrap_or_default().to_ascii_lowercase();
    let blocked_page_hosts = [
        "spotify.com",
        "youtube.com",
        "youtu.be",
        "soundcloud.com",
    ];
    if blocked_page_hosts
        .iter()
        .any(|domain| host == *domain || host.ends_with(&format!(".{domain}")))
    {
        return Err("Đây là liên kết trang nghe nhạc, không phải luồng âm thanh trực tiếp. VenusP không mở khóa Premium hoặc bỏ quảng cáo.");
    }

    let path = parsed.path().to_ascii_lowercase();
    let extension = path.rsplit('.').next().unwrap_or_default();
    if !ALLOWED_EXTENSIONS.contains(&extension) {
        return Err("Liên kết chưa đúng định dạng. Hãy dùng URL HTTPS trực tiếp có đuôi MP3, M4A, AAC, OGG, OPUS, FLAC, WAV hoặc M3U8.");
    }

    Ok(())
}

#[no_mangle]
pub extern "system" fn Java_com_venusp_player_RustCore_validateAudioUrl(
    mut env: JNIEnv,
    _this: JObject,
    input: JString,
) -> jstring {
    let result = match env.get_string(&input) {
        Ok(value) => {
            let owned: String = value.into();
            match validate_audio_url(&owned) {
                Ok(()) => "OK".to_string(),
                Err(message) => message.to_string(),
            }
        }
        Err(_) => "Không đọc được liên kết.".to_string(),
    };

    env.new_string(result)
        .map(|value| value.into_raw())
        .unwrap_or(std::ptr::null_mut())
}

#[cfg(test)]
mod tests {
    use super::validate_audio_url;

    #[test]
    fn accepts_https_mp3() {
        assert!(validate_audio_url("https://cdn.example.org/music/track.mp3?token=abc").is_ok());
    }

    #[test]
    fn rejects_spotify_page() {
        assert!(validate_audio_url("https://open.spotify.com/track/example").is_err());
    }

    #[test]
    fn rejects_non_https() {
        assert!(validate_audio_url("http://cdn.example.org/track.mp3").is_err());
    }
}
